<?php
//$dbName = "id15106176_";
//$user = "id15106176_";
//$pwd = "][)F)=c>7!|G+}|#";
//$host = "localhost";
//conn = new PDO('mysql:dbname='//.$dbName.';host='.$host, $user//, $pwd);
//api url filter
if(strpos($_SERVER['REQUEST_URI'],"DB.php")){
    require_once 'Utils.php';
    PlainDie();
}

$conn = new mysqli("localhost", "id16979567_dvamods1", "2n6&qbjdlmdMBrku", "id16979567_dvamods");
if($conn->connect_error != null){
    die($conn->connect_error);
}